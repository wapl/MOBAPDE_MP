package com.example.cinemainone;

import androidx.fragment.app.FragmentActivity;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback, GoogleMap.OnMarkerClickListener {

    private GoogleMap mMap;

    private Marker Theater1;
    private Marker Theater2;
    private Marker Theater3;
    private Marker Theater4;
    private Marker Theater5;
    private Marker Theater6;
    private Marker Theater7;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        LatLng th1 = new LatLng(14.65688, 121.03056);
        Theater1 = mMap.addMarker(new MarkerOptions().position(th1).title("Fisher Mall"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(th1));

        LatLng th2 = new LatLng(14.63363, 121.01926);
        Theater2 = mMap.addMarker(new MarkerOptions().position(th2).title("Trinoma"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(th2));

        LatLng th3 = new LatLng(14.6532, 121.03376);
        Theater3 = mMap.addMarker(new MarkerOptions().position(th3).title("Sm North Edsa"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(th3));

        LatLng th4 = new LatLng(14.58982, 120.98314);
        Theater4 = mMap.addMarker(new MarkerOptions().position(th4).title("Sm Manila"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(th4));

        LatLng th5 = new LatLng(14.57601, 120.98401);
        Theater5 = mMap.addMarker(new MarkerOptions().position(th5).title("Robinsons Manila"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(th5));

        LatLng th6 = new LatLng(14.62646, 121.08426);
        Theater6 = mMap.addMarker(new MarkerOptions().position(th6).title("Sm Marikina"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(th6));

        LatLng th7 = new LatLng(14.61833, 121.10002);
        Theater7 = mMap.addMarker(new MarkerOptions().position(th7).title("Sta. Lucia East Grand Mall"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(th7));

        mMap.setOnMarkerClickListener(this);

    }

    @Override
    public boolean onMarkerClick(Marker marker) {

        if (marker.equals(Theater1))
        {
            //data scaping and cinema informations etc etc
        }
        if (marker.equals(Theater2))
        {
            //data scaping and cinema informations etc etc
        }
        if (marker.equals(Theater3))
        {
            //data scaping and cinema informations etc etc
        }
        if (marker.equals(Theater4))
        {
            //data scaping and cinema informations etc etc
        }
        if (marker.equals(Theater5))
        {
            //data scaping and cinema informations etc etc
        }
        if (marker.equals(Theater6))
        {
            //data scaping and cinema informations etc etc
        }
        if (marker.equals(Theater7))
        {
            //data scaping and cinema informations etc etc
        }
        return false;
    }
}
